
public class healthclub {
	public static void main(String[] args) {
		int elevator=5;
		String place="";
		
	switch (elevator) {
		case 1 : place="�౹";
			break;

		case 2 : place="�����ܰ�";
			break;
		case 3 : place="�Ǻΰ�";
			break;
		case 4 : place="ġ��";
			break;
		default: place="�ｺŬ��";

	}
		System.out.println(place);
}
}
