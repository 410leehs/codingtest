public class VariablesScope {

	int zipCode =88560;
	public static void main(String[] args) {

	  int age =40;
	  System.out.println(zipCode);
	  System.out.println(age);
	}

}