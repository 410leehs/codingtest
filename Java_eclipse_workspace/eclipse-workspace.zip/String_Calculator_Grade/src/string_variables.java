
public class string_variables {
	public static void main(String[] args) {
		
		String adr="http://www.google.com";
		
		String wcms="Welcome to Google!";
		
		if(adr.startsWith("http") && adr.endsWith("com")) {
			
			if(adr.indexOf("google")==12) {
				}
			}
			System.out.println(wcms);
		}
	}

