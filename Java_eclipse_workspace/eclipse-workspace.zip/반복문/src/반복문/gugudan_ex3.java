package �ݺ���;

public class gugudan_ex3 {
	public static void main(String[] args) {
		int i;
		int j;

		for(i=1;i<=10;i++) {
			for(j=1;j<=10;j++) {
				if(i>=j) {
					System.out.println(i*j);
				}
			}
		}
	}
}