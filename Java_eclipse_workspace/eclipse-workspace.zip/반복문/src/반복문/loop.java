package �ݺ���;

public class loop {

	public static void main(String[] args) {
		int i;
		int j;
		int k=0;
		for(i=1;i<=9;i++) {
			for(j=1;j<=9;j++) {
				k=i * j;
			
				System.out.println(k);
			}
		}
		
		

	}

}
