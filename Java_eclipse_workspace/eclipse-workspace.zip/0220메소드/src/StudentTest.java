
public class StudentTest {
	public static void main(String[] args) {
		Student studentLee = new Student();
		//studentLee.studentName="������";
		studentLee.setStudentName("������");
		//studentLee.studentID;
		System.out.println(studentLee.getStudentName());
	}

}
