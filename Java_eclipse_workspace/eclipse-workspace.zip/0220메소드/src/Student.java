
public class Student {
	int studentID;
	private String studentName;
	int grade;
	String address;
	
	public void setStudentName (String studentName) {
		this.studentName=studentName;
	}
	public String getStudentName() {
		return studentName;
	}
}
