
public class DeskTop extends Computer{
	public void display() {
		System.out.println("DeskTop Display()");
	}
	public void typing() {
		System.out.println("DeskTop Typing()");
	}
}
