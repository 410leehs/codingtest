
public class MyNoteBook extends NoteBook{
	public void typing() {
		System.out.println("MyNoteBook Typing()");
	}
}
