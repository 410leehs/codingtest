
public abstract class NoteBook extends Computer{
	public void display() {
		System.out.println("NoteBook Display()");
	}
}
