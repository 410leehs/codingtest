
public class candidate {
	int age=40;
	String name="Lee";
	char marry='y';
	int child=2;
	public static void main(String[] args) {
		candidate candidate1=new candidate();
		
		
		System.out.println(candidate1.age);
		System.out.println(candidate1.name);
		System.out.println(candidate1.marry);
		System.out.println(candidate1.child);
	}

}
