public class BubbleSort implements Sort{
	public void ascending(int[] arr1) {
		System.out.println("BubbleSort ascending");
	}
	public void descending(int[] arr1) {
		System.out.println("BubbleSort descending");
	}
	public void description() {
		System.out.println("description");
	}
}
