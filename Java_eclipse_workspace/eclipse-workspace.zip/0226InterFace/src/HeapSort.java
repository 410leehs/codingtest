public class HeapSort implements Sort{
	public void ascending(int[] arr1) {
		System.out.println("HeapSort ascending");
	}
	public void descending(int[] arr1) {
		System.out.println("HeapSort descending");
	}
	public void description() {
		System.out.println("description");
	}
}
