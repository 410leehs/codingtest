
public class QuickSort implements Sort{
	public void ascending(int[] arr1) {
		System.out.println("QuickSort ascending");
	}
	public void descending(int[] arr1) {
		System.out.println("QuickSort descending");
	}
	public void description() {
		System.out.println("description");
	}
}
