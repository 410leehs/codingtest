
public interface Sort {
	public void ascending(int[] arr1);
	public void descending(int[] arr1);
	public void description();
}
