public class temperature {
	public static void main (String []args) {
	
		double C=20;
		double F= C*1.8+32;
		System.out.println(F+"��");
	}
}