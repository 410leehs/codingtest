
public class Average_Calculator_Project {
	public static void main (String[] args) {
		double math=80;
		double physics=70;
		double en=80;
		double program=90;
		double GPA = (math+physics+en+program)/4;
		System.out.println(GPA);
	}
}