
public class arithmetic {
	public static void main (String []args) {
		int amountOfApples = 15000000;
		int numOfApples = 79;
		
		int priceOfApples = amountOfApples / numOfApples;
		System.out.println(priceOfApples);
		
	}
}

